﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        message.Text = "Hello " + txt_username.Text + " ! ";
        message.Text = message.Text + " <br/> You have successfuly Registered with the following details.";
        ShowUserName.Text = txt_username.Text;
        ShowEmail.Text = txt_email.Text;
        if (rdb_m.Checked)
        {
            ShowGender.Text = rdb_m.Text;
        }
        else ShowGender.Text = rdb_f.Text;
        showbdate.Text = txt_bdate.Text;
        ShowUserNameLabel.Text = "User Name";
        ShowEmailIDLabel.Text = "Email ID";
        ShowGenderLabel.Text = "Gender";
        lbl_showbdate.Text = "Birth Date";
        txt_username.Text = "";
        txt_email.Text = "";
        rdb_f.Checked = false;
        rdb_m.Checked = false;        
    }
}