﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_create_Click(object sender, EventArgs e)
    {
        Response.Cookies["name"].Value = txt_create.Text;
        Response.Cookies["name"].Expires = DateTime.Now.AddMinutes(1);
        Label1.Text = "Cookie Created";
        txt_create.Text = "";
    }
    protected void btn_ret_Click(object sender, EventArgs e)
    {
        if (Request.Cookies["name"] == null)
        {
            txt_ret.Text = "No cookie found";
        }
        else
        {
            txt_ret.Text = Request.Cookies["name"].Value;
        }

    }
}