﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        ViewState["name"] = TextBox1.Text;
        ViewState["email"] = TextBox2.Text;

        TextBox1.Text = TextBox2.Text = string.Empty;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

        if (ViewState["name"] != null)
        {
            TextBox1.Text = ViewState["name"].ToString();
        }

        if (ViewState["email"] != null)
        {
            TextBox2.Text = ViewState["email"].ToString();
        }
    }
}